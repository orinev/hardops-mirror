from mathutils import Vector


def vector_sum(vectors):
    return sum(vectors, Vector())
